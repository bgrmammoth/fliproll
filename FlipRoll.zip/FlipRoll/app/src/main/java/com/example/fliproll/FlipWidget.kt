package com.example.fliproll

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class FlipWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { manager.updateAppWidget(it, buildViews(context)) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val value = when (intent.action) {
            ACTION_COIN -> Randomizer.coin(context)
            ACTION_DICE -> Randomizer.dice()
            else -> return
        }
        Randomizer.save(context, value)
        refreshAll(context)
    }

    companion object {
        private const val ACTION_COIN = "com.example.fliproll.COIN"
        private const val ACTION_DICE = "com.example.fliproll.DICE"

        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, FlipWidget::class.java))
            ids.forEach { mgr.updateAppWidget(it, buildViews(context)) }
        }

        private fun buildViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_layout)
            views.setTextViewText(R.id.result, Randomizer.last(context))
            views.setOnClickPendingIntent(R.id.btn_coin, pending(context, ACTION_COIN, 1))
            views.setOnClickPendingIntent(R.id.btn_dice, pending(context, ACTION_DICE, 2))
            return views
        }

        private fun pending(context: Context, action: String, code: Int): PendingIntent {
            val intent = Intent(context, FlipWidget::class.java).setAction(action)
            return PendingIntent.getBroadcast(
                context, code, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
