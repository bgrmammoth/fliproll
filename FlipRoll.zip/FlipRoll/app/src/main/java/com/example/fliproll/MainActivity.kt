package com.example.fliproll

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val result = findViewById<TextView>(R.id.result)
        result.text = Randomizer.last(this)

        fun show(value: String) {
            Randomizer.save(this, value)
            result.animate().rotationBy(360f).setDuration(300).withEndAction {
                result.text = value
                FlipWidget.refreshAll(this)
            }.start()
        }
        findViewById<android.widget.Button>(R.id.btn_coin).setOnClickListener { show(Randomizer.coin(this)) }
        findViewById<android.widget.Button>(R.id.btn_dice).setOnClickListener { show(Randomizer.dice()) }
    }
}
