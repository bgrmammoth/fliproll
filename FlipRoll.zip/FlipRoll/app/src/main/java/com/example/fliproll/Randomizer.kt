package com.example.fliproll

import android.content.Context
import kotlin.random.Random

object Randomizer {
    private const val PREFS = "fliproll"
    private const val KEY = "last"

    fun coin(ctx: Context): String =
        ctx.getString(if (Random.nextBoolean()) R.string.heads else R.string.tails)

    fun dice(): String = "\uD83C\uDFB2 ${Random.nextInt(1, 7)}"

    fun save(ctx: Context, value: String) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, value).apply()

    fun last(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "?") ?: "?"
}
